
#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

class Task {
private:
    string title;
    bool completed;
public:
    Task(string title) : title(title), completed(false) {}

    string getTitle() const { return title; }
    bool isCompleted() const { return completed; }

    void markCompleted() { completed = true; }

    string serialize() const {
        return title + "|" + (completed ? "1" : "0");
    }

    static Task deserialize(const string &data) {
        size_t delim = data.find('|');
        string title = data.substr(0, delim);
        bool status = data.substr(delim + 1) == "1";
        Task t(title);
        if (status) t.markCompleted();
        return t;
    }
};

class TaskManager {
private:
    vector<Task> tasks;

public:
    void addTask(const string &title) {
        tasks.emplace_back(title);
        cout << "Tugas ditambahkan.\n";
    }

    void showTasks() const {
        if (tasks.empty()) {
            cout << "Belum ada tugas.\n";
            return;
        }
        for (size_t i = 0; i < tasks.size(); ++i) {
            cout << i + 1 << ". " << tasks[i].getTitle()
                 << " [" << (tasks[i].isCompleted() ? "Selesai" : "Belum") << "]\n";
        }
    }

    void completeTask(int index) {
        if (index < 1 || index > tasks.size()) {
            cout << "Indeks tidak valid.\n";
            return;
        }
        tasks[index - 1].markCompleted();
        cout << "Tugas ditandai selesai.\n";
    }

    void deleteTask(int index) {
        if (index < 1 || index > tasks.size()) {
            cout << "Indeks tidak valid.\n";
            return;
        }
        tasks.erase(tasks.begin() + index - 1);
        cout << "Tugas dihapus.\n";
    }

    void saveToFile(const string &filename) const {
        ofstream out(filename);
        for (const auto &t : tasks) {
            out << t.serialize() << "\n";
        }
        out.close();
        cout << "Tugas disimpan ke file.\n";
    }

    void loadFromFile(const string &filename) {
        tasks.clear();
        ifstream in(filename);
        string line;
        while (getline(in, line)) {
            tasks.push_back(Task::deserialize(line));
        }
        in.close();
        cout << "Tugas dimuat dari file.\n";
    }
};

void menu() {
    cout << "\n=== Manajemen Tugas Mahasiswa ===\n";
    cout << "1. Tambah Tugas\n";
    cout << "2. Lihat Tugas\n";
    cout << "3. Tandai Selesai\n";
    cout << "4. Hapus Tugas\n";
    cout << "5. Simpan ke File\n";
    cout << "6. Muat dari File\n";
    cout << "0. Keluar\n";
    cout << "Pilih menu: ";
}

int main() {
    TaskManager manager;
    int choice;

    do {
        menu();
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1: {
                cout << "Judul Tugas: ";
                string title;
                getline(cin, title);
                manager.addTask(title);
                break;
            }
            case 2:
                manager.showTasks();
                break;
            case 3: {
                int idx;
                cout << "Nomor Tugas: ";
                cin >> idx;
                manager.completeTask(idx);
                break;
            }
            case 4: {
                int idx;
                cout << "Nomor Tugas: ";
                cin >> idx;
                manager.deleteTask(idx);
                break;
            }
            case 5:
                manager.saveToFile("tugas.txt");
                break;
            case 6:
                manager.loadFromFile("tugas.txt");
                break;
            case 0:
                cout << "Terima kasih! Program selesai.\n";
                break;
            default:
                cout << "Pilihan tidak valid.\n";
        }

    } while (choice != 0);

    return 0;
}
